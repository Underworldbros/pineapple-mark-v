<?php
// Auth validation
include_once('/pineapple/includes/api/auth.php');

// CSRF validation only for POST requests (write operations)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include_once('/pineapple/includes/api/csrf_check.php');
}

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'get_dhcp_leases':
            echo get_dhcp_leases_from_log();
            break;
        case 'get_blacklisted_macs':
            echo get_blacklisted_macs();
            break;
        case 'remove_blacklisted_mac':
            echo remove_mac_from_blacklist($_POST['mac_address']);
            break;
        case 'add_blacklisted_mac':
            echo add_mac_to_blacklist($_POST['mac_address']);
            break;
        case 'get_iw_wlan0_clients':
            echo get_iw_wlan0_connected_clients();
            break;
        case 'get_iw_wlan0_1_clients':
            echo get_iw_wlan0_1_connected_clients();
            break;
        case 'deauthenticate_mac_wlan0':
            echo deauth_wlan0_connected_mac($_POST['deauth_wlan0_mac_address']);
            break;
        case 'deauthenticate_mac_wlan0_1':
            echo deauth_wlan0_1_connected_mac($_POST['deauth_wlan0_1_mac_address']);
            break;
        case 'disassociate_mac_wlan0':
            echo disassociate_wlan0_connected_mac($_POST['disassociate_wlan0_mac_address']);
            break;
        case 'disassociate_mac_wlan0_1':
            echo disassociate_wlan0_1_connected_mac($_POST['disassociate_wlan0_1_mac_address']);
            break;
        case 'get_rogue_config':
            echo get_rogue_config();
            break;
        case 'set_rogue_subnet':
            echo set_rogue_subnet($_POST['preset']);
            break;
        case 'get_brlan_clients':
            echo get_brlan_connected_clients();
            break;
        case 'get_rogue_clients':
            echo get_rogue_connected_clients();
            break;
        case 'get_dashboard':
            echo get_dashboard();
            break;
        case 'get_leases':
            echo get_leases();
            break;
        case 'release_lease':
            echo release_lease($_POST['mac']);
            break;
        case 'renew_lease':
            echo renew_lease($_POST['mac']);
            break;
        case 'get_static_leases':
            echo get_static_leases();
            break;
        case 'add_static_lease':
            echo add_static_lease($_POST['mac'], $_POST['ip'], isset($_POST['hostname']) ? $_POST['hostname'] : '');
            break;
        case 'delete_static_lease':
            echo delete_static_lease($_POST['mac']);
            break;
        case 'get_dhcp_ranges':
            echo get_dhcp_ranges();
            break;
        case 'get_dhcp_log':
            echo get_dhcp_log();
            break;
        case 'clear_log':
            echo clear_dhcp_log();
            break;
        case 'export_leases':
            export_leases_csv();
            break;
    }
}

// This function parses the DHCP leases in /tmp/dhcp.leases file
// it is used to build the clients tab
function get_dhcp_leases_from_log(){
    $logs = array();
    array_push($logs, htmlspecialchars(file_get_contents('/tmp/dhcp.leases')));
    $html = json_encode($logs);
    return $html;
}

// This function gets the mac addresses in karmas blacklist
function get_blacklisted_macs(){
    exec("pineapple karma list_macs", $mac_list);
    $html = json_encode($mac_list);
    return $html;
} 

// This function removes a mac address from karmas blacklist
function remove_mac_from_blacklist($mac){
    exec('pineapple karma del_mac "'.$mac.'"');                  
    return "";
}

// This function adds a mac address to karmas blacklist
function add_mac_to_blacklist($mac){
    exec('pineapple karma add_mac "'.$mac.'"');
    return "";
}

// This function gets the list of clients connected to wlan0 from iw
function get_iw_wlan0_connected_clients(){
    exec("iw dev wlan0 station dump | grep Station | awk '{print $2}'", $iw_connected_clients);
    $html = json_encode($iw_connected_clients);
    return $html;
}

// This function gets the list of clients connected to wlan0-1 from iw
function get_iw_wlan0_1_connected_clients(){
    exec("iw dev wlan0-1 station dump | grep Station | awk '{print $2}'", $iw_connected_clients);
    $html = json_encode($iw_connected_clients);
    return $html;
}

// This function gets clients on br-lan (ethernet/wired) from DHCP leases - only 172.16.42.x
function get_brlan_connected_clients(){
    $leases_file = '/tmp/dhcp.leases';
    $clients = array();
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $ip = $parts[2];
                // Only show br-lan clients (172.16.42.x)
                if (strpos($ip, '172.16.42.') === 0) {
                    $mac = $parts[1];
                    $hostname = count($parts) >= 4 ? $parts[3] : '';
                    $clients[] = array('mac' => $mac, 'ip' => $ip, 'hostname' => $hostname);
                }
            }
        }
    }
    
    return json_encode($clients);
}

// This function gets clients on rogue (wlan0) from DHCP leases - 192.168.0.x or 10.0.0.x
function get_rogue_connected_clients(){
    $leases_file = '/tmp/dhcp.leases';
    $clients = array();
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $ip = $parts[2];
                // Only show rogue clients (192.168.0.x or 10.0.0.x)
                if (strpos($ip, '192.168.0.') === 0 || strpos($ip, '10.0.0.') === 0) {
                    $mac = $parts[1];
                    $hostname = count($parts) >= 4 ? $parts[3] : '';
                    $clients[] = array('mac' => $mac, 'ip' => $ip, 'hostname' => $hostname);
                }
            }
        }
    }
    
    return json_encode($clients);
}

// This function deauthenticates a mac address connected to wlan0 using hostapd_cli
function deauth_wlan0_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0 deauthenticate "'.$mac.'"');
   return "";
}

// This function deauthenticates a mac address connected to wlan0-1 using hostapd_cli
function deauth_wlan0_1_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0-1 deauthenticate "'.$mac.'"');
   return "";
}

// This function disassociates a mac address connected to wlan0 using hostapd_cli
function disassociate_wlan0_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0 disassociate "'.$mac.'"');
   return "";
}

// This function disassociates a mac address connected to wlan0-1 using hostapd_cli
function disassociate_wlan0_1_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0-1 disassociate "'.$mac.'"');
   return "";
}

// Get current rogue AP configuration status
function get_rogue_config(){
    exec('sh /sd/connectedclients/switch_subnet.sh status 2>&1', $output);
    return implode("\n", $output);
}

// Switch rogue AP subnet preset
function set_rogue_subnet($preset){
    // Validate preset
    $allowed = array('home', 'business', 'default');
    if (!in_array($preset, $allowed)) {
        return json_encode(array('error' => 'Invalid preset'));
    }
    exec('sh /sd/connectedclients/switch_subnet.sh ' . escapeshellarg($preset) . ' 2>&1', $output);
    return json_encode(array('result' => implode("\n", $output)));
}

// DHCP Manager Functions

// Get DHCP Manager dashboard info
function get_dashboard(){
    $data = array();
    
    // Get br-lan info
    exec("uci get network.lan.ipaddr", $brlan_ip);
    exec("uci get network.lan.netmask", $brlan_mask);
    exec("uci get dhcp.lan.limit", $brlan_limit);
    
    $brlan_clients = intval(count_clients_in_subnet('172.16.42.'));
    $brlan_total = isset($brlan_limit[0]) ? intval($brlan_limit[0]) : 150;
    
    $data['brlan'] = array(
        'ip' => isset($brlan_ip[0]) ? trim($brlan_ip[0]) : '172.16.42.1',
        'subnet' => '172.16.42',
        'clients' => $brlan_clients,
        'total_ips' => $brlan_total
    );
    
    // Get rogue AP info
    exec("sh /sd/connectedclients/switch_subnet.sh status 2>&1", $rogue_status);
    $preset = strpos(implode(" ", $rogue_status), 'business') !== false ? 'business' : 'home';
    
    $rogue_clients = intval(count_clients_in_subnet($preset === 'business' ? '10.0.0.' : '192.168.0.'));
    
    $data['rogue'] = array(
        'ip' => $preset === 'business' ? '10.0.0.1' : '192.168.0.1',
        'preset' => $preset,
        'clients' => $rogue_clients
    );
    
    // Get wlan0-1 info
    $wlan0_1_clients = intval(count_clients_in_subnet('192.168.1.'));
    $data['wlan0_1'] = array(
        'clients' => $wlan0_1_clients
    );
    
    // Count total leases
    $data['total_leases'] = intval($brlan_clients + $rogue_clients + $wlan0_1_clients);
    
    return json_encode($data);
}

// Count clients in a subnet
function count_clients_in_subnet($subnet_prefix){
    $count = 0;
    $leases_file = '/tmp/dhcp.leases';
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines) && count($lines) > 0) {
            foreach ($lines as $line) {
                if (!empty($line)) {
                    $parts = explode(' ', $line);
                    if (count($parts) >= 3 && !empty($parts[2]) && strpos($parts[2], $subnet_prefix) === 0) {
                        $count++;
                    }
                }
            }
        }
    }
    
    return intval($count);
}

// Get active DHCP leases
function get_leases(){
    $leases = array();
    $leases_file = '/tmp/dhcp.leases';
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $mac = $parts[1];
                $ip = $parts[2];
                $hostname = count($parts) >= 4 ? $parts[3] : 'unknown';
                
                $leases[] = array(
                    'mac' => $mac,
                    'ip' => $ip,
                    'hostname' => $hostname,
                    'vendor' => get_mac_vendor($mac)
                );
            }
        }
    }
    
    return json_encode($leases);
}

// Get MAC vendor from first 3 octets
function get_mac_vendor($mac){
    // Simple vendor lookup - could be expanded
    $vendors = array(
        'aa:bb:cc' => 'Vendor A',
        'dd:ee:ff' => 'Vendor B'
    );
    
    $prefix = strtolower(substr($mac, 0, 8));
    return isset($vendors[$prefix]) ? $vendors[$prefix] : 'Unknown';
}

// Release a DHCP lease
function release_lease($mac){
    exec("dhcp_release " . escapeshellarg($mac));
    return json_encode(array('status' => 'released'));
}

// Renew a DHCP lease
function renew_lease($mac){
    exec("dhcp_renew " . escapeshellarg($mac));
    return json_encode(array('status' => 'renew_sent'));
}

// Get static DHCP leases
function get_static_leases(){
    $leases = array();
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    
    if (file_exists($static_file)) {
        $lines = file($static_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, 'dhcp-host=') === 0) {
                $parts = explode(',', str_replace('dhcp-host=', '', $line));
                if (count($parts) >= 2) {
                    $leases[] = array(
                        'mac' => trim($parts[0]),
                        'ip' => trim($parts[1]),
                        'hostname' => isset($parts[2]) ? trim($parts[2]) : ''
                    );
                }
            }
        }
    }
    
    return json_encode($leases);
}

// Add a static DHCP lease
function add_static_lease($mac, $ip, $hostname){
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    $entry = "dhcp-host=" . $mac . "," . $ip;
    if ($hostname) {
        $entry .= "," . $hostname;
    }
    $entry .= "\n";
    
    file_put_contents($static_file, $entry, FILE_APPEND);
    exec("killall -HUP dnsmasq");
    
    return json_encode(array('status' => 'added'));
}

// Delete a static DHCP lease
function delete_static_lease($mac){
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    
    if (file_exists($static_file)) {
        $lines = file($static_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $new_lines = array();
        
        foreach ($lines as $line) {
            if (strpos($line, $mac) === false) {
                $new_lines[] = $line;
            }
        }
        
        file_put_contents($static_file, implode("\n", $new_lines) . "\n");
        exec("killall -HUP dnsmasq");
    }
    
    return json_encode(array('status' => 'deleted'));
}

// Get DHCP ranges
function get_dhcp_ranges(){
    $ranges = array();
    
    // br-lan range
    exec("uci get dhcp.lan.start", $brlan_start);
    exec("uci get dhcp.lan.limit", $brlan_limit);
    $ranges[] = array(
        'interface' => 'br-lan (172.16.42.x)',
        'start' => isset($brlan_start[0]) ? $brlan_start[0] : '100',
        'limit' => isset($brlan_limit[0]) ? $brlan_limit[0] : '150'
    );
    
    // Rogue range
    $ranges[] = array(
        'interface' => 'Rogue (192.168.0.x/10.0.0.x)',
        'start' => '100',
        'limit' => '150'
    );
    
    return json_encode($ranges);
}

// Get DHCP log
function get_dhcp_log(){
    $log = array();
    $log_file = '/var/log/dnsmasq.log';
    
    if (file_exists($log_file)) {
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        // Get last 100 lines
        $lines = array_slice($lines, -100);
        
        foreach ($lines as $line) {
            if (strpos($line, 'DHCP') !== false) {
                $log[] = htmlspecialchars($line);
            }
        }
    }
    
    return json_encode($log);
}

// Clear DHCP log
function clear_dhcp_log(){
    exec("> /var/log/dnsmasq.log");
    return json_encode(array('status' => 'cleared'));
}

// Export leases as CSV
function export_leases_csv(){
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="dhcp_leases_' . date('Y-m-d_H-i-s') . '.csv"');
    
    $leases_file = '/tmp/dhcp.leases';
    echo "MAC,IP,Hostname,Vendor\n";
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $mac = $parts[1];
                $ip = $parts[2];
                $hostname = count($parts) >= 4 ? $parts[3] : 'unknown';
                $vendor = get_mac_vendor($mac);
                
                echo "\"" . $mac . "\",\"" . $ip . "\",\"" . $hostname . "\",\"" . $vendor . "\"\n";
            }
        }
    }
    
    exit;
}

?>
