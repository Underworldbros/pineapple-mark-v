<?php
// Auth validation
include_once('/pineapple/includes/api/auth.php');

// CSRF validation only for POST requests (write operations)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include_once('/pineapple/includes/api/csrf_check.php');
}

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'get_dhcp_leases':
            echo get_dhcp_leases_from_log();
            break;
        case 'get_blacklisted_macs':
            echo get_blacklisted_macs();
            break;
        case 'remove_blacklisted_mac':
            echo remove_mac_from_blacklist($_POST['mac_address']);
            break;
        case 'add_blacklisted_mac':
            echo add_mac_to_blacklist($_POST['mac_address']);
            break;
        case 'get_iw_wlan0_clients':
            echo get_iw_wlan0_connected_clients();
            break;
        case 'get_iw_wlan0_1_clients':
            echo get_iw_wlan0_1_connected_clients();
            break;
        case 'deauthenticate_mac_wlan0':
            echo deauth_wlan0_connected_mac($_POST['deauth_wlan0_mac_address']);
            break;
        case 'deauthenticate_mac_wlan0_1':
            echo deauth_wlan0_1_connected_mac($_POST['deauth_wlan0_1_mac_address']);
            break;
        case 'disassociate_mac_wlan0':
            echo disassociate_wlan0_connected_mac($_POST['disassociate_wlan0_mac_address']);
            break;
        case 'disassociate_mac_wlan0_1':
            echo disassociate_wlan0_1_connected_mac($_POST['disassociate_wlan0_1_mac_address']);
            break;
        case 'get_rogue_config':
            echo get_rogue_config();
            break;
        case 'set_rogue_subnet':
            echo set_rogue_subnet($_POST['preset']);
            break;
        case 'get_brlan_clients':
            echo get_brlan_connected_clients();
            break;
        case 'get_rogue_clients':
            echo get_rogue_connected_clients();
            break;
        case 'get_dashboard':
            echo get_dashboard();
            break;
        case 'get_leases':
            echo get_leases();
            break;
        case 'release_lease':
            echo release_lease($_POST['mac']);
            break;
        case 'renew_lease':
            echo renew_lease($_POST['mac']);
            break;
        case 'get_static_leases':
            echo get_static_leases();
            break;
        case 'add_static_lease':
            echo add_static_lease($_POST['mac'], $_POST['ip'], isset($_POST['hostname']) ? $_POST['hostname'] : '');
            break;
        case 'delete_static_lease':
            echo delete_static_lease($_POST['mac']);
            break;
        case 'get_dhcp_ranges':
            echo get_dhcp_ranges();
            break;
        case 'get_dhcp_log':
            echo get_dhcp_log();
            break;
        case 'clear_log':
            echo clear_dhcp_log();
            break;
        case 'export_leases':
            export_leases_csv();
            break;
    }
}

// This function parses the DHCP leases in /tmp/dhcp.leases file
// it is used to build the clients tab
function get_dhcp_leases_from_log(){
    $logs = array();
    array_push($logs, htmlspecialchars(file_get_contents('/tmp/dhcp.leases')));
    $html = json_encode($logs);
    return $html;
}

// This function gets the mac addresses in karmas blacklist
function get_blacklisted_macs(){
    exec("pineapple karma list_macs", $mac_list);
    $html = json_encode($mac_list);
    return $html;
} 

// This function removes a mac address from karmas blacklist
function remove_mac_from_blacklist($mac){
    exec('pineapple karma del_mac "'.$mac.'"');                  
    return "";
}

// This function adds a mac address to karmas blacklist
function add_mac_to_blacklist($mac){
    exec('pineapple karma add_mac "'.$mac.'"');
    return "";
}

// This function gets the list of clients connected to wlan0 from iw
function get_iw_wlan0_connected_clients(){
    exec("iw dev wlan0 station dump | grep Station | awk '{print $2}'", $iw_connected_clients);
    $html = json_encode($iw_connected_clients);
    return $html;
}

// This function gets the list of clients connected to wlan0-1 from iw
function get_iw_wlan0_1_connected_clients(){
    exec("iw dev wlan0-1 station dump | grep Station | awk '{print $2}'", $iw_connected_clients);
    $html = json_encode($iw_connected_clients);
    return $html;
}

// This function gets clients on br-lan (ethernet/wired) from DHCP leases - only 172.16.42.x
function get_brlan_connected_clients(){
    $leases_file = '/tmp/dhcp.leases';
    $clients = array();
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $ip = $parts[2];
                // Only show br-lan clients (172.16.42.x)
                if (strpos($ip, '172.16.42.') === 0) {
                    $mac = $parts[1];
                    $hostname = count($parts) >= 4 ? $parts[3] : '';
                    $clients[] = array('mac' => $mac, 'ip' => $ip, 'hostname' => $hostname);
                }
            }
        }
    }
    
    return json_encode($clients);
}

// This function gets clients on rogue (wlan0) from DHCP leases - 192.168.0.x or 10.0.0.x
function get_rogue_connected_clients(){
    $leases_file = '/tmp/dhcp.leases';
    $clients = array();
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $ip = $parts[2];
                // Only show rogue clients (192.168.0.x or 10.0.0.x)
                if (strpos($ip, '192.168.0.') === 0 || strpos($ip, '10.0.0.') === 0) {
                    $mac = $parts[1];
                    $hostname = count($parts) >= 4 ? $parts[3] : '';
                    $clients[] = array('mac' => $mac, 'ip' => $ip, 'hostname' => $hostname);
                }
            }
        }
    }
    
    return json_encode($clients);
}

// This function deauthenticates a mac address connected to wlan0 using hostapd_cli
function deauth_wlan0_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0 deauthenticate "'.$mac.'"');
   return "";
}

// This function deauthenticates a mac address connected to wlan0-1 using hostapd_cli
function deauth_wlan0_1_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0-1 deauthenticate "'.$mac.'"');
   return "";
}

// This function disassociates a mac address connected to wlan0 using hostapd_cli
function disassociate_wlan0_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0 disassociate "'.$mac.'"');
   return "";
}

// This function disassociates a mac address connected to wlan0-1 using hostapd_cli
function disassociate_wlan0_1_connected_mac($mac){
   exec('hostapd_cli -p /var/run/hostapd-phy0 -i wlan0-1 disassociate "'.$mac.'"');
   return "";
}

// Get current rogue AP configuration status
function get_rogue_config(){
    exec('sh /sd/connectedclients/switch_subnet.sh status 2>&1', $output);
    return implode("\n", $output);
}

// Switch rogue AP subnet preset
function set_rogue_subnet($preset){
    // Validate preset
    $allowed = array('home', 'business', 'default');
    if (!in_array($preset, $allowed)) {
        return json_encode(array('error' => 'Invalid preset'));
    }
    exec('sh /sd/connectedclients/switch_subnet.sh ' . escapeshellarg($preset) . ' 2>&1', $output);
    return json_encode(array('result' => implode("\n", $output)));
}

// DHCP Manager Functions

// Get DHCP Manager dashboard info
function get_dashboard(){
    $data = array();
    
    // Get br-lan info
    exec("uci get network.lan.ipaddr", $brlan_ip);
    exec("uci get network.lan.netmask", $brlan_mask);
    exec("uci get dhcp.lan.limit", $brlan_limit);
    
    $brlan_clients = intval(count_clients_in_subnet('172.16.42.'));
    $brlan_total = isset($brlan_limit[0]) ? intval($brlan_limit[0]) : 150;
    
    $data['brlan'] = array(
        'ip' => isset($brlan_ip[0]) ? trim($brlan_ip[0]) : '172.16.42.1',
        'subnet' => '172.16.42',
        'clients' => $brlan_clients,
        'total_ips' => $brlan_total
    );
    
    // Get rogue AP info
    exec("sh /sd/connectedclients/switch_subnet.sh status 2>&1", $rogue_status);
    $preset = strpos(implode(" ", $rogue_status), 'business') !== false ? 'business' : 'home';
    
    $rogue_clients = intval(count_clients_in_subnet($preset === 'business' ? '10.0.0.' : '192.168.0.'));
    
    $data['rogue'] = array(
        'ip' => $preset === 'business' ? '10.0.0.1' : '192.168.0.1',
        'preset' => $preset,
        'clients' => $rogue_clients
    );
    
    // Get wlan0-1 info
    $wlan0_1_clients = intval(count_clients_in_subnet('192.168.1.'));
    $data['wlan0_1'] = array(
        'clients' => $wlan0_1_clients
    );
    
    // Count total leases
    $data['total_leases'] = intval($brlan_clients + $rogue_clients + $wlan0_1_clients);
    
    return json_encode($data);
}

// Count clients in a subnet
function count_clients_in_subnet($subnet_prefix){
    $count = 0;
    $leases_file = '/tmp/dhcp.leases';
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines) && count($lines) > 0) {
            foreach ($lines as $line) {
                if (!empty($line)) {
                    $parts = explode(' ', $line);
                    if (count($parts) >= 3 && !empty($parts[2]) && strpos($parts[2], $subnet_prefix) === 0) {
                        $count++;
                    }
                }
            }
        }
    }
    
    return intval($count);
}

// Get active DHCP leases
function get_leases(){
    $leases = array();
    $leases_file = '/tmp/dhcp.leases';
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $mac = $parts[1];
                $ip = $parts[2];
                $hostname = count($parts) >= 4 ? $parts[3] : 'unknown';
                
                $leases[] = array(
                    'mac' => $mac,
                    'ip' => $ip,
                    'hostname' => $hostname,
                    'vendor' => get_mac_vendor($mac)
                );
            }
        }
    }
    
    return json_encode($leases);
}

// Get MAC vendor from first 3 octets (OUI lookup)
function get_mac_vendor($mac){
    // Common vendor OUI database (first 6 characters = 3 octets)
    $vendors = array(
        // Apple
        '00:03:93' => 'Apple',
        '00:04:75' => 'Apple',
        '00:0a:95' => 'Apple',
        '00:0b:46' => 'Apple',
        '00:1a:92' => 'Apple',
        '00:1d:4f' => 'Apple',
        '00:1e:52' => 'Apple',
        '00:1e:c2' => 'Apple',
        '00:1f:5b' => 'Apple',
        '00:21:82' => 'Apple',
        '00:22:41' => 'Apple',
        '00:23:12' => 'Apple',
        '00:23:6c' => 'Apple',
        '00:24:36' => 'Apple',
        '00:25:00' => 'Apple',
        '00:25:86' => 'Apple',
        '00:25:bc' => 'Apple',
        '00:26:b0' => 'Apple',
        '00:26:f2' => 'Apple',
        '00:27:13' => 'Apple',
        '00:2a:f7' => 'Apple',
        '00:2e:6f' => 'Apple',
        '00:30:65' => 'Apple',
        '00:3e:e1' => 'Apple',
        '00:50:2f' => 'Apple',
        '00:60:1d' => 'Apple',
        '00:66:4b' => 'Apple',
        '00:6b:f1' => 'Apple',
        '00:84:47' => 'Apple',
        '00:87:95' => 'Apple',
        '00:8f:f0' => 'Apple',
        '00:9a:9d' => 'Apple',
        '00:a0:40' => 'Apple',
        '00:a1:97' => 'Apple',
        '00:ad:d0' => 'Apple',
        '00:b0:d0' => 'Apple',
        '00:c6:10' => 'Apple',
        '00:d4:97' => 'Apple',
        '00:e0:4c' => 'Apple',
        '00:f4:b9' => 'Apple',
        '04:f1:38' => 'Apple',
        '0c:74:c3' => 'Apple',
        '10:40:f3' => 'Apple',
        '14:cc:20' => 'Apple',
        '18:65:90' => 'Apple',
        '18:8b:45' => 'Apple',
        '1c:52:16' => 'Apple',
        '20:c5:d9' => 'Apple',
        '24:a0:74' => 'Apple',
        '28:37:37' => 'Apple',
        '2c:f0:ee' => 'Apple',
        '30:10:e8' => 'Apple',
        '34:15:9c' => 'Apple',
        '34:ab:37' => 'Apple',
        '38:c0:14' => 'Apple',
        '3c:15:c2' => 'Apple',
        '40:16:8e' => 'Apple',
        '44:2a:60' => 'Apple',
        '48:d7:05' => 'Apple',
        '4c:00:10' => 'Apple',
        '50:3d:e5' => 'Apple',
        '54:26:96' => 'Apple',
        '58:1f:aa' => 'Apple',
        '5c:0a:5b' => 'Apple',
        '60:33:4b' => 'Apple',
        '64:76:ba' => 'Apple',
        '68:a8:6d' => 'Apple',
        '6c:40:08' => 'Apple',
        '70:48:0f' => 'Apple',
        '74:e5:0b' => 'Apple',
        '78:31:f1' => 'Apple',
        '7c:d1:c3' => 'Apple',
        '80:00:6e' => 'Apple',
        '80:e6:50' => 'Apple',
        '84:38:35' => 'Apple',
        '88:63:df' => 'Apple',
        '8c:2e:85' => 'Apple',
        '90:84:0d' => 'Apple',
        '94:de:80' => 'Apple',
        '98:01:a7' => 'Apple',
        '98:ca:ed' => 'Apple',
        '9c:29:19' => 'Apple',
        'a0:14:3d' => 'Apple',
        'a4:83:e7' => 'Apple',
        'a8:5b:78' => 'Apple',
        'ac:3c:0b' => 'Apple',
        'ac:de:80' => 'Apple',
        'b0:34:95' => 'Apple',
        'b4:55:cc' => 'Apple',
        'b8:09:8a' => 'Apple',
        'b8:78:2e' => 'Apple',
        'bc:54:2e' => 'Apple',
        'c0:25:06' => 'Apple',
        'c4:2c:03' => 'Apple',
        'c8:6c:87' => 'Apple',
        'cc:2d:e0' => 'Apple',
        'd0:23:db' => 'Apple',
        'd4:6e:0e' => 'Apple',
        'd8:30:62' => 'Apple',
        'dc:2b:61' => 'Apple',
        'e0:ac:cb' => 'Apple',
        'e4:8b:46' => 'Apple',
        'e8:84:a5' => 'Apple',
        'ec:35:86' => 'Apple',
        'f0:18:98' => 'Apple',
        'f4:0f:24' => 'Apple',
        'f8:01:13' => 'Apple',
        'fc:65:de' => 'Apple',
        
        // Samsung
        '00:07:ab' => 'Samsung',
        '00:09:18' => 'Samsung',
        '00:12:fb' => 'Samsung',
        '00:13:77' => 'Samsung',
        '00:16:6b' => 'Samsung',
        '00:1a:8a' => 'Samsung',
        '00:1e:4c' => 'Samsung',
        '00:22:a1' => 'Samsung',
        '00:23:be' => 'Samsung',
        '00:24:be' => 'Samsung',
        '00:26:37' => 'Samsung',
        '00:37:6b' => 'Samsung',
        '00:3e:98' => 'Samsung',
        '14:cc:20' => 'Samsung',
        '18:3a:2c' => 'Samsung',
        '20:1a:4a' => 'Samsung',
        '28:21:86' => 'Samsung',
        '2c:11:22' => 'Samsung',
        '34:80:0d' => 'Samsung',
        '38:ca:da' => 'Samsung',
        '3c:37:86' => 'Samsung',
        '40:d8:55' => 'Samsung',
        '44:e9:dd' => 'Samsung',
        '48:93:fe' => 'Samsung',
        '4c:41:1e' => 'Samsung',
        '50:64:2f' => 'Samsung',
        '54:27:1e' => 'Samsung',
        '58:03:b5' => 'Samsung',
        '5c:ab:94' => 'Samsung',
        '60:d8:19' => 'Samsung',
        '64:31:50' => 'Samsung',
        '68:d7:d0' => 'Samsung',
        '6c:72:e7' => 'Samsung',
        '70:3b:09' => 'Samsung',
        '74:40:bb' => 'Samsung',
        '78:47:1d' => 'Samsung',
        '7c:4c:a5' => 'Samsung',
        '80:00:60' => 'Samsung',
        '84:2a:fb' => 'Samsung',
        '88:50:f3' => 'Samsung',
        '8c:21:0a' => 'Samsung',
        '90:09:b6' => 'Samsung',
        '94:35:0a' => 'Samsung',
        '98:b6:e9' => 'Samsung',
        '9c:2a:70' => 'Samsung',
        'a0:0b:ba' => 'Samsung',
        'a4:12:69' => 'Samsung',
        'a8:5e:60' => 'Samsung',
        'ac:64:17' => 'Samsung',
        'b0:22:7a' => 'Samsung',
        'b4:79:a7' => 'Samsung',
        'b8:e8:56' => 'Samsung',
        'bc:14:01' => 'Samsung',
        'c0:06:c3' => 'Samsung',
        'c4:85:08' => 'Samsung',
        'c8:09:a6' => 'Samsung',
        'cc:20:e6' => 'Samsung',
        'd0:12:16' => 'Samsung',
        'd4:6d:7e' => 'Samsung',
        'd8:0f:99' => 'Samsung',
        'dc:37:14' => 'Samsung',
        'e0:28:6d' => 'Samsung',
        'e4:ce:8f' => 'Samsung',
        'e8:92:a4' => 'Samsung',
        'ec:1a:59' => 'Samsung',
        'f0:72:ea' => 'Samsung',
        
        // Google
        '00:18:0a' => 'Google',
        '00:26:12' => 'Google',
        '14:cc:20' => 'Google',
        '28:69:6a' => 'Google',
        '34:08:04' => 'Google',
        '38:63:bb' => 'Google',
        '40:16:3e' => 'Google',
        '48:5a:3f' => 'Google',
        '50:f5:da' => 'Google',
        '5a:e1:db' => 'Google',
        '64:9c:0e' => 'Google',
        '6a:c7:17' => 'Google',
        '74:6d:28' => 'Google',
        '7a:66:a8' => 'Google',
        '84:ef:18' => 'Google',
        '8a:36:9f' => 'Google',
        '90:e2:ba' => 'Google',
        '9e:75:a7' => 'Google',
        'a4:36:bc' => 'Google',
        
        // Microsoft
        '00:1d:c1' => 'Microsoft',
        '00:50:f2' => 'Microsoft',
        '14:cc:20' => 'Microsoft',
        '1c:6f:65' => 'Microsoft',
        '24:4a:3e' => 'Microsoft',
        '28:18:78' => 'Microsoft',
        '38:2c:4a' => 'Microsoft',
        '44:fb:42' => 'Microsoft',
        '4c:cc:6a' => 'Microsoft',
        '54:53:ed' => 'Microsoft',
        '5c:f9:38' => 'Microsoft',
        '64:1c:41' => 'Microsoft',
        '6c:ad:ad' => 'Microsoft',
        '74:6e:0b' => 'Microsoft',
        '7c:1e:52' => 'Microsoft',
        '84:8d:6b' => 'Microsoft',
        '8c:89:a5' => 'Microsoft',
        '94:de:80' => 'Microsoft',
        '9c:37:f5' => 'Microsoft',
        'a4:ba:db' => 'Microsoft',
        'ac:5f:3e' => 'Microsoft',
        'b4:6b:fc' => 'Microsoft',
        'bc:77:37' => 'Microsoft',
        'c4:46:19' => 'Microsoft',
        'cc:40:d9' => 'Microsoft',
        'd4:25:8b' => 'Microsoft',
        'dc:37:14' => 'Microsoft',
        'e4:11:5b' => 'Microsoft',
        'ec:f4:bb' => 'Microsoft',
        'f4:4e:fd' => 'Microsoft',
        
        // Intel
        '00:02:b3' => 'Intel',
        '00:1f:3c' => 'Intel',
        '14:cc:20' => 'Intel',
        '1c:6f:65' => 'Intel',
        '24:be:05' => 'Intel',
        '3c:97:0e' => 'Intel',
        '54:ab:3a' => 'Intel',
        '5c:f3:70' => 'Intel',
        '64:9a:04' => 'Intel',
        '7c:7a:91' => 'Intel',
        '84:7b:9b' => 'Intel',
        '94:de:80' => 'Intel',
        'a4:ba:db' => 'Intel',
        'ac:5f:3e' => 'Intel',
        'c4:85:08' => 'Intel',
        'cc:2d:e0' => 'Intel',
        'd4:6e:0e' => 'Intel',
        'ec:f4:bb' => 'Intel',
        
        // Broadcom/Qualcomm
        '00:04:4b' => 'Broadcom',
        '00:0f:66' => 'Broadcom',
        '00:19:35' => 'Broadcom',
        '00:1e:3a' => 'Broadcom',
        '00:23:f8' => 'Broadcom',
        '14:cc:20' => 'Broadcom',
        '1c:5f:2b' => 'Broadcom',
        '24:77:03' => 'Broadcom',
        '2c:f0:ee' => 'Broadcom',
        '34:13:e8' => 'Broadcom',
        '3c:37:86' => 'Broadcom',
        '44:48:c1' => 'Broadcom',
        '4c:5e:0c' => 'Broadcom',
        '54:04:a6' => 'Broadcom',
        '5c:51:88' => 'Broadcom',
        '64:9d:99' => 'Broadcom',
        '6c:85:56' => 'Broadcom',
        '74:de:2b' => 'Broadcom',
        '7c:b2:6d' => 'Broadcom',
        '84:1b:5e' => 'Broadcom',
        '8c:79:59' => 'Broadcom',
        '94:10:3e' => 'Broadcom',
        '9c:b6:54' => 'Broadcom',
        'a4:ae:12' => 'Broadcom',
        'ac:7b:a1' => 'Broadcom',
        'b4:00:20' => 'Broadcom',
        'bc:14:01' => 'Broadcom',
        'c4:00:ad' => 'Broadcom',
        'cc:40:d9' => 'Broadcom',
        'd4:6e:0e' => 'Broadcom',
        'dc:a9:04' => 'Broadcom',
        'e4:f4:c6' => 'Broadcom',
        'ec:55:f9' => 'Broadcom',
        'f4:4e:fd' => 'Broadcom',
    );
    
    $prefix = strtolower(substr($mac, 0, 8));
    return isset($vendors[$prefix]) ? $vendors[$prefix] : 'Unknown';
}

// Release a DHCP lease
function release_lease($mac){
    exec("dhcp_release " . escapeshellarg($mac));
    return json_encode(array('status' => 'released'));
}

// Renew a DHCP lease
function renew_lease($mac){
    exec("dhcp_renew " . escapeshellarg($mac));
    return json_encode(array('status' => 'renew_sent'));
}

// Get static DHCP leases
function get_static_leases(){
    $leases = array();
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    
    if (file_exists($static_file)) {
        $lines = file($static_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, 'dhcp-host=') === 0) {
                $parts = explode(',', str_replace('dhcp-host=', '', $line));
                if (count($parts) >= 2) {
                    $leases[] = array(
                        'mac' => trim($parts[0]),
                        'ip' => trim($parts[1]),
                        'hostname' => isset($parts[2]) ? trim($parts[2]) : ''
                    );
                }
            }
        }
    }
    
    return json_encode($leases);
}

// Add a static DHCP lease
function add_static_lease($mac, $ip, $hostname){
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    $entry = "dhcp-host=" . $mac . "," . $ip;
    if ($hostname) {
        $entry .= "," . $hostname;
    }
    $entry .= "\n";
    
    file_put_contents($static_file, $entry, FILE_APPEND);
    exec("killall -HUP dnsmasq");
    
    return json_encode(array('status' => 'added'));
}

// Delete a static DHCP lease
function delete_static_lease($mac){
    $static_file = '/etc/dnsmasq.d/static_dhcp';
    
    if (file_exists($static_file)) {
        $lines = file($static_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $new_lines = array();
        
        foreach ($lines as $line) {
            if (strpos($line, $mac) === false) {
                $new_lines[] = $line;
            }
        }
        
        file_put_contents($static_file, implode("\n", $new_lines) . "\n");
        exec("killall -HUP dnsmasq");
    }
    
    return json_encode(array('status' => 'deleted'));
}

// Get DHCP ranges
function get_dhcp_ranges(){
    $ranges = array();
    
    // br-lan range
    exec("uci get dhcp.lan.start", $brlan_start);
    exec("uci get dhcp.lan.limit", $brlan_limit);
    $ranges[] = array(
        'interface' => 'br-lan (172.16.42.x)',
        'start' => isset($brlan_start[0]) ? $brlan_start[0] : '100',
        'limit' => isset($brlan_limit[0]) ? $brlan_limit[0] : '150'
    );
    
    // Rogue range
    $ranges[] = array(
        'interface' => 'Rogue (192.168.0.x/10.0.0.x)',
        'start' => '100',
        'limit' => '150'
    );
    
    return json_encode($ranges);
}

// Get DHCP log
function get_dhcp_log(){
    $log = array();
    $log_file = '/var/log/dnsmasq.log';
    
    if (file_exists($log_file)) {
        $lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        // Get last 100 lines
        $lines = array_slice($lines, -100);
        
        foreach ($lines as $line) {
            if (strpos($line, 'DHCP') !== false) {
                $log[] = htmlspecialchars($line);
            }
        }
    }
    
    return json_encode($log);
}

// Clear DHCP log
function clear_dhcp_log(){
    exec("> /var/log/dnsmasq.log");
    return json_encode(array('status' => 'cleared'));
}

// Export leases as CSV
function export_leases_csv(){
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="dhcp_leases_' . date('Y-m-d_H-i-s') . '.csv"');
    
    $leases_file = '/tmp/dhcp.leases';
    echo "MAC,IP,Hostname,Vendor\n";
    
    if (file_exists($leases_file)) {
        $lines = file($leases_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $parts = explode(' ', $line);
            if (count($parts) >= 3) {
                $mac = $parts[1];
                $ip = $parts[2];
                $hostname = count($parts) >= 4 ? $parts[3] : 'unknown';
                $vendor = get_mac_vendor($mac);
                
                echo "\"" . $mac . "\",\"" . $ip . "\",\"" . $hostname . "\",\"" . $vendor . "\"\n";
            }
        }
    }
    
    exit;
}

?>
