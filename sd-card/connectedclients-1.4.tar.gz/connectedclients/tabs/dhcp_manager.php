<script type='text/javascript' src='/components/infusions/connectedclients/js/dhcp_manager.js'></script>

<h2>DHCP Manager</h2>

<hr />

<ul id="dhcp_tabs" style="list-style:none;padding:0;margin:0 0 10px 0;">
<li style="display:inline-block;margin-right:3px;"><a href="#" id="tab_dashboard" class="dhcp_tab_active" onclick="dhcp_show_tab('dashboard');return false;" style="padding:5px 10px;cursor:pointer;text-decoration:none;color:#fff;background:#333;">Dashboard</a></li>
<li style="display:inline-block;margin-right:3px;"><a href="#" id="tab_leases" onclick="dhcp_show_tab('leases');return false;" style="padding:5px 10px;cursor:pointer;text-decoration:none;color:#ccc;background:#222;">Leases</a></li>
<li style="display:inline-block;margin-right:3px;"><a href="#" id="tab_static" onclick="dhcp_show_tab('static');return false;" style="padding:5px 10px;cursor:pointer;text-decoration:none;color:#ccc;background:#222;">Static</a></li>
<li style="display:inline-block;margin-right:3px;"><a href="#" id="tab_ranges" onclick="dhcp_show_tab('ranges');return false;" style="padding:5px 10px;cursor:pointer;text-decoration:none;color:#ccc;background:#222;">Ranges</a></li>
<li style="display:inline-block;margin-right:3px;"><a href="#" id="tab_log" onclick="dhcp_show_tab('log');return false;" style="padding:5px 10px;cursor:pointer;text-decoration:none;color:#ccc;background:#222;">Log</a></li>
</ul>

<div id="dhcp_tab_content">Loading...</div>

<form id="dhcp_export_form" name="dhcp_export_form" action="/components/infusions/connectedclients/functions.php?action=export_leases" method="POST" target="_blank">
<input type="hidden" id="dhcp_export_csrf" name="_csrfToken" value="" />
</form>

<script type="text/javascript">
// Auto-load dashboard on tab open
dhcp_load_dashboard();
</script>
