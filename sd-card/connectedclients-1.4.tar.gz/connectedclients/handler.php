<?php
#########################
#    User Variables     #
#   Please edit these   #
#########################
$name = 'DHCP Manager';  #Name of tile
$updatable = 'false';  #Should this tile auto-refresh
$version = '1.4';

#########################
#     Handler Code      #
# No need to edit below #
#########################

#Set up handler functions and data
include('/pineapple/includes/api/tile_functions.php');
$directory = realpath(dirname(__FILE__)).'/';
$rel_dir = str_replace('/pineapple', '', $directory);
include('/pineapple/includes/api/handler_helper.php');

#########################
#  Initialization Code  #
#########################

# Initialize rogue AP configuration on first install
if (is_file($directory . 'switch_subnet.sh')) {
    // Ensure DHCP ranges are configured and initialize rogue AP
    exec('sh ' . escapeshellarg($directory . 'switch_subnet.sh') . ' status 2>&1', $output);
    
    // Ensure config file exists
    $config_file = '/sd/connectedclients/rogue_preset.conf';
    if (!file_exists($config_file)) {
        // Write default preset (home)
        file_put_contents($config_file, 'home');
        // Initialize the rogue AP with home preset
        exec('sh ' . escapeshellarg($directory . 'switch_subnet.sh') . ' home 2>&1', $output);
    }
}

?>