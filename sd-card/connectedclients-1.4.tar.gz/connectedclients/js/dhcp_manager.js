function dhcp_show_tab(tab) {
    $('#dhcp_tabs a').css('background','#222').css('color','#ccc');
    $('#tab_' + tab).css('background','#333').css('color','#fff');
    
    if (tab == 'dashboard') {
        dhcp_load_dashboard();
    } else if (tab == 'leases') {
        dhcp_load_leases();
    } else if (tab == 'static') {
        dhcp_load_static();
    } else if (tab == 'ranges') {
        dhcp_load_ranges();
    } else if (tab == 'log') {
        dhcp_load_log();
    }
}

function dhcp_load_dashboard() {
    $.get('/components/infusions/connectedclients/functions.php?action=get_dashboard', function(data) {
        try {
            var d = JSON.parse(data);
            
            var rogue_label = d.rogue.preset == 'home' ? 'Home (192.168.0.x)' : 'Business (10.0.0.x)';
            var rogue_color = d.rogue.preset == 'home' ? '#0f0' : '#0af';
            
            var html = '<table style="border-spacing:15px 5px;width:100%;">';
            
            html += '<tr><td colspan="3"><h3>Interface Status</h3></td></tr>';
            html += '<tr><td style="padding:10px;background:#222;border:1px solid #444;width:33%;">';
            html += '<b style="color:#0af;">Ethernet (br-lan)</b><br/>';
            html += 'IP: ' + d.brlan.ip + '<br/>';
            html += 'Subnet: ' + d.brlan.subnet + '.x<br/>';
            html += 'Clients: <span style="color:#0f0;">' + d.brlan.clients + '</span>';
            html += '</td>';
            
            html += '<td style="padding:10px;background:#222;border:1px solid #444;width:33%;">';
            html += '<b style="color:' + rogue_color + ';">Rogue AP (wlan0)</b><br/>';
            html += 'IP: ' + (d.rogue.ip || 'N/A') + '<br/>';
            html += 'Preset: ' + rogue_label + '<br/>';
            html += 'Clients: <span style="color:#0f0;">' + d.rogue.clients + '</span>';
            html += '</td>';
            
            html += '<td style="padding:10px;background:#222;border:1px solid #444;width:33%;">';
            html += '<b style="color:#fa0;">wlan0-1</b><br/>';
            html += 'Internet Sharing<br/>';
            html += 'Clients: <span style="color:#0f0;">' + d.wlan0_1.clients + '</span>';
            html += '</td></tr>';
            
            html += '<tr><td colspan="3"><h3>DHCP Pool Status</h3></td></tr>';
            
            var brlan_pct = Math.round((d.brlan.clients / d.brlan.total_ips) * 100);
            var brlan_color = brlan_pct > 80 ? '#f00' : (brlan_pct > 60 ? '#fa0' : '#0f0');
            
            html += '<tr><td style="padding:10px;background:#222;border:1px solid #444;">';
            html += '<b>br-lan Pool</b><br/>';
            html += '<div style="background:#444;height:20px;width:100%;margin:5px 0;">';
            html += '<div style="background:' + brlan_color + ';height:100%;width:' + brlan_pct + '%;"></div>';
            html += '</div>';
            html += d.brlan.clients + ' / ' + d.brlan.total_ips + ' used (' + brlan_pct + '%)';
            html += '</td>';
            
            html += '<td style="padding:10px;background:#222;border:1px solid #444;">';
            html += '<b>Rogue Pool</b><br/>';
            html += '<div style="background:#444;height:20px;width:100%;margin:5px 0;">';
            html += '<div style="background:#0f0;height:100%;width:' + Math.min(100, Math.round((d.rogue.clients / 150) * 100)) + '%;"></div>';
            html += '</div>';
            html += d.rogue.clients + ' / 150 used';
            html += '</td>';
            
            html += '<td style="padding:10px;background:#222;border:1px solid #444;">';
            html += '<b>Total Active Leases</b><br/>';
            html += '<span style="font-size:24px;color:#0f0;">' + d.total_leases + '</span>';
            html += '</td></tr>';
            
            html += '</table>';
            
            $('#dhcp_tab_content').html(html);
        } catch(e) {
            $('#dhcp_tab_content').html('Error: ' + e);
        }
    });
}

function dhcp_load_leases() {
    $.get('/components/infusions/connectedclients/functions.php?action=get_leases', function(data) {
        try {
            var leases = JSON.parse(data);
            
            var html = '<div style="margin-bottom:10px;">';
            html += '<button onclick="dhcp_export_csv()">Export CSV</button> ';
            html += '<button onclick="dhcp_load_leases()">Refresh</button> ';
            html += '<button onclick="dhcp_update_vendors()" style="color:#00dd00; background:#002200; padding:5px 10px; border:1px solid #00dd00; cursor:pointer;">Update Vendors</button>';
            html += '<span id="vendor_update_status" style="margin-left:10px; font-weight:bold;"></span>';
            html += '</div>';
            
            if (leases.length == 0) {
                html += '<p>No active leases</p>';
            } else {
                html += '<table style="width:100%;border-collapse:collapse;border-spacing:0;">';
                html += '<tr style="background:#333;"><th style="padding:8px;text-align:left;">MAC</th><th style="padding:8px;text-align:left;">IP</th><th style="padding:8px;text-align:left;">Hostname</th><th style="padding:8px;text-align:left;">Vendor</th><th style="padding:8px;text-align:left;">Actions</th></tr>';
                
                for (var i = 0; i < leases.length; i++) {
                    var row_bg = i % 2 == 0 ? '#222' : '#1a1a1a';
                    html += '<tr style="background:' + row_bg + ';">';
                    html += '<td style="padding:6px;">' + leases[i].mac + '</td>';
                    html += '<td style="padding:6px;">' + leases[i].ip + '</td>';
                    html += '<td style="padding:6px;">' + (leases[i].hostname || '<em>unknown</em>') + '</td>';
                    html += '<td style="padding:6px;">' + leases[i].vendor + '</td>';
                    html += '<td style="padding:6px;">';
                    html += '<a href="#" onclick="dhcp_release_lease(\'' + leases[i].mac + '\')" style="color:#f66;">Release</a> ';
                    html += '<a href="#" onclick="dhcp_renew_lease(\'' + leases[i].mac + '\')" style="color:#6f6;">Renew</a>';
                    html += '</td></tr>';
                }
                html += '</table>';
            }
            
            $('#dhcp_tab_content').html(html);
        } catch(e) {
            $('#dhcp_tab_content').html('Error: ' + e);
        }
    });
}

function dhcp_release_lease(mac) {
    if (!confirm('Release lease for ' + mac + '?')) return;
    
    $.post('/components/infusions/connectedclients/functions.php?action=release_lease', 
        { mac: mac, _csrfToken: $('meta[name=_csrfToken]').attr('content') },
        function(data) {
            alert('Lease released');
            dhcp_load_leases();
        }
    );
}

function dhcp_renew_lease(mac) {
    $.post('/components/infusions/connectedclients/functions.php?action=renew_lease', 
        { mac: mac, _csrfToken: $('meta[name=_csrfToken]').attr('content') },
        function(data) {
            alert('DHCP renew signal sent');
        }
    );
}

function dhcp_update_vendors() {
    var status = $('#vendor_update_status');
    status.text('Downloading OUI database...');
    status.css('color', '#ff9900');
    
    $.post('/components/infusions/connectedclients/functions.php?action=update_oui_database', {}, function(data) {
        try {
            var result = JSON.parse(data);
            if (result.success) {
                status.text('✓ ' + result.message);
                status.css('color', '#00dd00');
                setTimeout(function() {
                    status.text('');
                    dhcp_load_leases();
                }, 3000);
            } else {
                status.text('✗ ' + result.message);
                status.css('color', '#ff4444');
            }
        } catch(e) {
            status.text('✗ Error: ' + e);
            status.css('color', '#ff4444');
        }
    }).fail(function() {
        status.text('✗ Request failed - check console');
        status.css('color', '#ff4444');
    });
}

function dhcp_export_csv() {
    document.getElementById('dhcp_export_csrf').value = $('meta[name=_csrfToken]').attr('content');
    document.getElementById('dhcp_export_form').submit();
}

function dhcp_load_static() {
    $.get('/components/infusions/connectedclients/functions.php?action=get_static_leases', function(data) {
        try {
            var leases = JSON.parse(data);
            
            var html = '<div style="margin-bottom:10px;">';
            html += '<button onclick="dhcp_show_add_static()">Add Static Lease</button> ';
            html += '<button onclick="dhcp_load_static()">Refresh</button>';
            html += '</div>';
            
            html += '<div id="add_static_form" style="display:none;padding:10px;background:#222;margin-bottom:10px;">';
            html += '<h4>Add Static Lease</h4>';
            html += 'MAC: <input type="text" id="static_mac" placeholder="aa:bb:cc:dd:ee:ff"><br/><br/>';
            html += 'IP: <input type="text" id="static_ip" placeholder="172.16.42.100"><br/><br/>';
            html += 'Hostname: <input type="text" id="static_hostname" placeholder="mydevice"><br/><br/>';
            html += '<button onclick="dhcp_add_static()">Add</button> ';
            html += '<button onclick="$(\'#add_static_form\').hide()">Cancel</button>';
            html += '</div>';
            
            if (leases.length == 0) {
                html += '<p>No static leases configured</p>';
            } else {
                html += '<table style="width:100%;border-collapse:collapse;border-spacing:0;">';
                html += '<tr style="background:#333;"><th style="padding:8px;text-align:left;">MAC</th><th style="padding:8px;text-align:left;">IP</th><th style="padding:8px;text-align:left;">Hostname</th><th style="padding:8px;text-align:left;">Actions</th></tr>';
                
                for (var i = 0; i < leases.length; i++) {
                    var row_bg = i % 2 == 0 ? '#222' : '#1a1a1a';
                    html += '<tr style="background:' + row_bg + ';">';
                    html += '<td style="padding:6px;">' + leases[i].mac + '</td>';
                    html += '<td style="padding:6px;">' + leases[i].ip + '</td>';
                    html += '<td style="padding:6px;">' + (leases[i].hostname || '<em>none</em>') + '</td>';
                    html += '<td style="padding:6px;">';
                    html += '<a href="#" onclick="dhcp_delete_static(\'' + leases[i].mac + '\')" style="color:#f66;">Delete</a>';
                    html += '</td></tr>';
                }
                html += '</table>';
            }
            
            $('#dhcp_tab_content').html(html);
        } catch(e) {
            $('#dhcp_tab_content').html('Error: ' + e);
        }
    });
}

function dhcp_show_add_static() {
    $('#add_static_form').show();
}

function dhcp_add_static() {
    var mac = $('#static_mac').val();
    var ip = $('#static_ip').val();
    var hostname = $('#static_hostname').val();
    
    if (!mac || !ip) {
        alert('MAC and IP are required');
        return;
    }
    
    $.post('/components/infusions/connectedclients/functions.php?action=add_static_lease',
        { mac: mac, ip: ip, hostname: hostname, _csrfToken: $('meta[name=_csrfToken]').attr('content') },
        function(data) {
            $('#add_static_form').hide();
            $('#static_mac').val('');
            $('#static_ip').val('');
            $('#static_hostname').val('');
            dhcp_load_static();
        }
    );
}

function dhcp_delete_static(mac) {
    if (!confirm('Delete static lease for ' + mac + '?')) return;
    
    $.post('/components/infusions/connectedclients/functions.php?action=delete_static_lease',
        { mac: mac, _csrfToken: $('meta[name=_csrfToken]').attr('content') },
        function(data) {
            dhcp_load_static();
        }
    );
}

function dhcp_load_ranges() {
    $.get('/components/infusions/connectedclients/functions.php?action=get_dhcp_ranges', function(data) {
        try {
            var ranges = JSON.parse(data);
            
            var html = '<table style="width:100%;border-collapse:collapse;border-spacing:0;">';
            html += '<tr style="background:#333;"><th style="padding:8px;text-align:left;">Interface</th><th style="padding:8px;text-align:left;">Start IP</th><th style="padding:8px;text-align:left;">Limit</th><th style="padding:8px;text-align:left;">Actions</th></tr>';
            
            for (var i = 0; i < ranges.length; i++) {
                var row_bg = i % 2 == 0 ? '#222' : '#1a1a1a';
                html += '<tr style="background:' + row_bg + ';">';
                html += '<td style="padding:6px;">' + ranges[i].interface + '</td>';
                html += '<td style="padding:6px;">' + ranges[i].start + '</td>';
                html += '<td style="padding:6px;">' + ranges[i].limit + '</td>';
                html += '<td style="padding:6px;">';
                html += '<span style="color:#666;">View only</span>';
                html += '</td></tr>';
            }
            html += '</table>';
            
            $('#dhcp_tab_content').html(html);
        } catch(e) {
            $('#dhcp_tab_content').html('Error: ' + e);
        }
    });
}

function dhcp_load_log() {
    $.get('/components/infusions/connectedclients/functions.php?action=get_dhcp_log', function(data) {
        try {
            var log = JSON.parse(data);
            
            var html = '<div style="margin-bottom:10px;">';
            html += '<button onclick="dhcp_clear_log()">Clear Log</button> ';
            html += '<button onclick="dhcp_load_log()">Refresh</button>';
            html += '</div>';
            
            if (log.length == 0) {
                html += '<p>No log entries</p>';
            } else {
                html += '<pre style="background:#111;padding:10px;overflow:auto;max-height:400px;">';
                for (var i = 0; i < log.length; i++) {
                    html += log[i] + '\n';
                }
                html += '</pre>';
            }
            
            $('#dhcp_tab_content').html(html);
        } catch(e) {
            $('#dhcp_tab_content').html('Error: ' + e);
        }
    });
}

function dhcp_clear_log() {
    if (!confirm('Clear all log entries?')) return;
    
    $.post('/components/infusions/connectedclients/functions.php?action=clear_log',
        { _csrfToken: $('meta[name=_csrfToken]').attr('content') },
        function(data) {
            dhcp_load_log();
        }
    );
}
